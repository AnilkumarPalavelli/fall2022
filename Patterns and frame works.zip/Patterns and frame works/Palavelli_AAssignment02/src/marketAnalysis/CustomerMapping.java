/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marketAnalysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class CustomerMapping {
     private HashMap<Customer, LinkedList<Product>> marketBasket;
     
    /**
     * No-arg constructor
     */ 
    public CustomerMapping() {
    	marketBasket=new HashMap<>();
       
    }
    /**
     * Getter method
     * @return marketBasket hashmap
     */
    public HashMap<Customer, LinkedList<Product>> getMarketBasket() {
        return marketBasket;
    }

    /**
     *This method add the given product to the customer key of the marketBasket 
     * hashmap. If the customer does not exist, create a new entry in the 
     * marketBasket hashmap.
     * @param customer
     * @param product
     */
    public void addProduct(Customer customer, Product product) {
       if(marketBasket.containsKey(customer)) {
    	   LinkedList<Product>prod=marketBasket.get(customer);
    	   prod.add(product);
    	   marketBasket.put(customer, prod);
    	   
       }
       else {
    	   LinkedList<Product>prod1=new LinkedList<Product>();
    	   prod1.add(product);
    	   marketBasket.put(customer, prod1);
    	   
       }
    }

    /**
     * This method finds the total number of customers in the marketBasket 
     * hashmap who purchased the given product with given brand.
     * @param productName
     * @param brandName
     * @return total number of the customers
     */
    public int findNoOfCustomers(String productName, String brandName) {
        int count=0;
        for(Customer custom:marketBasket.keySet()) {
        	for(Product produc:marketBasket.get(custom)) {
        		if(produc.getProductBrand().equalsIgnoreCase(brandName)&&produc.getProductName().equalsIgnoreCase(productName)) {
        			count++;
        		}
        	}
        }
        return count;
    }
    
    /**
     * This method finds the customer names those who purchased the products with 
     * the given brandName. 
     * @param brandName
     * @return Set of customer names.
     */
    public Set<String> whoPurchasedProduct(String brandName) {
        Set<String>customers=new HashSet<>();
        for(Customer cus:marketBasket.keySet()) {
        	for(Product pro:marketBasket.get(cus)) {
        		if(pro.getProductBrand().equalsIgnoreCase(brandName)) {
        			customers.add(cus.getName());
        		}
        		
        	}
        }
        return customers;
    }

    /**
     *This method returns all the unique products in the marketBasket hashmap.
     * @return all the unique products in the marketBasket.
     */
    public List<Product> getProducts() {
        List<Product>productlist=new ArrayList<>();
        for(Customer custem:marketBasket.keySet()) {
        	for(Product prode:marketBasket.get(custem)) {
        		if(!productlist.contains(prode)) {
        			productlist.add(prode);
        		}
        	}
        }
        return productlist;
    }

    /**
     * This method returns all the available brands for a given product.
     * @param productName
     * @return Set of brand names of the given product.
     */
    public Set<String> findAllBrands(String productName) {
    	Set<String>allbrands=new HashSet<>();
    	for(Customer custer:marketBasket.keySet()) {
    		for(Product prodec:marketBasket.get(custer)) {
    			if(prodec.getProductName().equalsIgnoreCase(productName)) {
    				allbrands.add(prodec.getProductBrand());
    			}
    		}
    	}
        
        return allbrands;
    }
    
    /**
     * This method returns the size of the marketBasket hashmap.
     * @return the size of the marketBasket
     */
    public int size() {
        return marketBasket.size();
    }
}
