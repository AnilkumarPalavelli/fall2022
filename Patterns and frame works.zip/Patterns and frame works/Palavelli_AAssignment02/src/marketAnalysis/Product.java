/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marketAnalysis;

import java.util.Objects;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Product {
	private String productName;
	private String productBrand;

	public Product(String productName, String productBrand) {
		super();
		this.productName = productName;
		this.productBrand = productBrand;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductBrand() {
		return productBrand;
	}

	@Override
	public int hashCode() {
		return Objects.hash(productBrand, productName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(productBrand, other.productBrand) && Objects.equals(productName, other.productName);
	}

	@Override
	public String toString() {
		return  productName+"-"+productBrand;
	}

}
