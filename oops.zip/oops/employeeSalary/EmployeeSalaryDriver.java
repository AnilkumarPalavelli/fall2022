
package employeeSalary;
import java.util.Scanner;

/**
 *this class is a driver class of employee salary class
 * @author Anilkumar Palavelli_S549406
 */
public class EmployeeSalaryDriver {

    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Testing the EmployeeSalary class:");
        System.out.println("Enter the wage per hour of the Employee: $");
        //Created the scanner class instance
        Scanner sc = new Scanner(System.in);
        double salary=sc.nextDouble();
        System.out.print("Enter the insurance percentage of the Employee in percentage:");
        double insurance=sc.nextDouble();
        System.out.print("Enter the tax percentage of the Employee in percentage:");
        double taxp=sc.nextDouble();
        System.out.print("Enter the pf percentage of the Employee in percentage:");
        double pfp=sc.nextDouble();
        System.out.print("Enter the bonus of the Employee:");
        double bonus=sc.nextDouble();
        System.out.print("The details of obj1EmpSal object are as follows:");
        //created a new object named obj1EmpSal
        EmployeeSalary obj1EmpSal=new EmployeeSalary(salary,insurance,taxp,pfp);
        System.out.println(obj1EmpSal);
        System.out.println("The monthly salary of the Employee is :" +obj1EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is :" +obj1EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is :" +obj1EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is :" +obj1EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is :" +obj1EmpSal.calcAnnualNetPay(bonus));
        System.out.println("**************************************************");
        //created new object named obj1EmpSal
        EmployeeSalary obj2EmpSal=new EmployeeSalary();
        System.out.println(obj2EmpSal);
        System.out.println("The monthly salary of the Employee is :" +obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is :" +obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is :" +obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is :" +obj2EmpSal.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is :" +obj2EmpSal.calcAnnualNetPay(bonus));
        System.out.print("Enter the new bonus of the Employee ");
        double newbonus=sc.nextDouble();
        System.out.println("The details of Obj2EmpSal object are as follows:");
        obj2EmpSal.setWagePerHour(35.0);
        obj2EmpSal.setInsurancePercentage(12.5);
        obj2EmpSal.setTaxPercentage(11.45);
        obj2EmpSal.setPfPercentage(10.5);
        System.out.println(obj2EmpSal);
        System.out.println("The monthly salary of the Employee is :" +obj2EmpSal.calcMonthlySalary());
        System.out.println("The monthly insurance of the Employee is :" +obj2EmpSal.calcMonthlyInsurance());
        System.out.println("The monthly pf of the Employee is :" +obj2EmpSal.calcMonthlyPfAmount());
        System.out.println("The annual gross salary of the Employee is :" +obj2EmpSal.calcAnnualGrossSalary(4000.0));
        System.out.println("The gross annual net pay of the Employee is :" +obj2EmpSal.calcAnnualNetPay(4000.0));
        
        
                
        
        
        
        
        
        
        
        
    }
    
}
