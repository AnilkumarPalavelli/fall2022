insert into modules values(1,ERdiagram);
insert into modules values(2,Normalization);

select moduleID,moduleName from modules;
