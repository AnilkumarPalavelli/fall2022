/*Q1*/

create table VEHICLE(License_Plate varchar(20) PRIMARY KEY,Vehicle_Name varchar(20),Model_num number,Vehicle_Type varchar(10));
create table CUSTOMER(Customer_Id varchar(10) PRIMARY KEY,Customer_Name varchar(20),Phone varchar(10),Address_Line1 varchar(20),Address_Line2 varchar(20),City varchar(10),State varchar(10),Postal_Code number,Country varchar(10));
create table LOCATION(Location_Id varchar(10) PRIMARY KEY,Address_Line1 varchar(20),Address_Line2 varchar(20),City varchar(10),State varchar(10),Postal_Code number,Country varchar(10));
create table RESERVATION(Reservation_Id number PRIMARY KEY,Customer_Id varchar(10) REFERENCES CUSTOMER(Customer_Id),License_Plate varchar(20) REFERENCES VEHICLE(License_Plate),Location_Id varchar(10) REFERENCES LOCATION(Location_Id),Pickup_Date date,Return_Date date);

/*Q2*/

insert into vehicle values('TS04P3223','SUZUKI ALTO',33,'MICRO');
insert into vehicle values('TS04J9852','BREZZA',23,'SUV');
insert into vehicle values('AP16BF1182','MG HECTOR',41,'SUV');
insert into vehicle values('AP20P3574','FORTUNER',20,'SUV');

/*Q3*/

insert into customer values('S54','Anil','6605285034','APT 31','University','Maryville','Missouri',64468,'US');
insert into customer values('S55','kumar','6605285121','APT 25','Campus','Maryville','Missouri',64468,'US');
insert into customer values('S56','Teja','6605288132','APT 10','Parkway','Maryville','Missouri',64468,'US');
insert into customer values('S57','Hari','6605281972','APT 31','Village','Maryville','Missouri',64468,'US');

insert into location values(333,'APT 29','Maryville','Missouri','MO',64468,'US');
insert into location values(222,'APT 31','Albany','New York','NY',12222,'US');
insert into location values(444,'APT 11','Denton','Texas','TX',76203,'US');
insert into location values(555,'APT 5','Cleveland','Ohio','OH',44115,'US');

insert into reservation values (49406,'S54','TS04P3223',333,'03-sep-2022','05-sep-2022');
insert into reservation values(54401,'S55','TS04J9852',222,'03-sep-2022','08-sep-2022');
insert into reservation values (55118,'S56','AP16BF1182',444,'05-sep-2022','12-sep-2022');
insert into reservation values(49407,'S57','AP20P3574',555,'08-sep-2022','22-sep-2022');


/*Q4*/
select *from CUSTOMER;
select *from VEHICLE;
select *from LOCATION;
select *from RESERVATION;

/*Q5*/

alter table CUSTOMER add(Customer_Requirement varchar(10));

/*Q6*/

select *from VEHICLE where Vehicle_Name='FORTUNER';


/*Q7*/

drop table RESERVATION;
drop table CUSTOMER;
drop table VEHICLE;
drop table LOCATION;

/*Q8*/

ROLLBACK;


/*Q9:Difference between drop, truncate and delete

DELETE :This command deletes one or more existing records from the table in the database based upon the condition written.

DROP  : This  Command delets the complete table from the database.

TRUNCATE :This Command deletes all the rows from the existing table, leaving the row with the column names.
*/


/*Q10:Aggregate functions

1.MAX() : MAX  function returns the Maximum value  in a set of non-NULL values.

2.MIN() : MIN  function returns the MINIMUM value in a set of non-NULL values.

3.SUM() : SUM function returns the total sum of a numeric column.

4.COUNT(): COUNT function returns the number of rows in a database table.

5.AVG() :  AVG function calculates the average of a set of values.
*/