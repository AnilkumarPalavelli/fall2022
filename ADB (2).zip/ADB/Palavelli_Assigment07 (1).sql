/* Question 1*/

Insert into POSRep values(100,'Palavelli','Anil');
Insert into POSRep values(101,'Palavelli','Hari');
Insert into POSRep values(102,'Chitrala','Bhanu');
Insert into POSRep values(103,'Anumula','Anjith');
Insert into POSRep values(104,'Vakadani','Uday');
Insert into POSRep values(105,'Balupari','Krishna');

Select *From POSRep;


Insert into Customer values(200,'Sulthan','Uday');
Insert into Customer values(201,'Bandla','SaiMahesh');
Insert into Customer values(202,'Rayankula','Yeshwanth');
Insert into Customer values(203,'Sulthan','Renu');
Insert into Customer values(204,'Tati','GopalaKrishna');
Insert into Customer values(205,'Jangili','Manikanta');

Select *From Customer;


Insert into Order_Table values(300,'10-Sep-2022','Laptop',200);
Insert into Order_Table values(301,'20-Oct-2022','Bag',201);
Insert into Order_Table values(302,'15-Sep-2022','Mobile',202);
Insert into Order_Table values(303,'11-Sep-2022','Laptop',203);
Insert into Order_Table values(304,'22-Oct-2022','Bag',204);
Insert into Order_Table values(305,'05-Sep-2022','Mobile',205);
Insert into Order_Table values(306,'30-Sep-2022','Laptop',200);
Insert into Order_Table values(307,'28-Oct-2022','Bag',201);
Insert into Order_Table values(308,'25-Sep-2022','Mobile',202);
Insert into Order_Table values(309,'15-Sep-2022','Laptop',203);


Select *From Order_Table;




Insert into Contact_Details values(400,'9182054109','sulthan@gmail.com',200);
Insert into Contact_Details values(401,'9121403967','SaiMahesh@gmail.com',201);
Insert into Contact_Details values(402,'9010123456','Yeshwanth@gmail.com',202);
Insert into Contact_Details values(403,'9876543210','Renu@mail.com',202);
Insert into Contact_Details values(404,'7890564312','GopalaKrishna@gmail.com',200);
Insert into Contact_Details values(405,'9398567890','Manikanta@gmail.com',200);

Select *From  Contact_Details;



Insert into State values(500,'Missouri','US');
Insert into State values(501,'Ohio','US');
Insert into State values(502,'Chicago','US');
Insert into State values(503,'New York','US');
Insert into State values(504,'Arizona','US');
Insert into State values(505,'California','US');


Select *From State;


Insert into Product values(600,'Laptop','laptop',1500);
Insert into Product values(601,'Bag','School bag',20);
Insert into Product values(602,'Mobile','cell phone',1000);
Insert into Product values(603,'Book','book',10);
Insert into Product values(604,'Pencil','pencil',5);
Insert into Product values(605,'Ipad','ipad',200);
Insert into Product values(606,'Shirt','dress',100);
Insert into Product values(607,'Airpods','airdopes',245);
Insert into Product values(608,'Comforter','comforter',50);
Insert into Product values(609,'bottle','water bottle',60);
Insert into product values(610,'pepsi','cool drink',20);

Select *From Product;


Insert into POLine values(700,3,1000,300,600);
Insert into POLine values(701,2,400,301,601);
Insert into POLine values(702,3,200,302,602);
Insert into POLine values(703,4,500,303,603);
Insert into POLine values(704,5,240,304,604);
Insert into POLine values(705,6,350,305,605);
Insert into POLine values(706,7,250,306,606);
Insert into POLine values(707,4,450,307,607);
Insert into POLine values(708,2,245,308,608);
Insert into POLine values(709,6,890,309,609);

select *from POLine;

insert into address values(801,'campus view',21,'maryville',64468,500,200);
insert into address values(802,'parkway',12,'cleveland',45011,501,201);
insert into address values(803,'village o',16,'chicago',60007,502,202);
insert into address values(804,'horizons',58,'Newyork',54481,503,203);
insert into address values(805,'wrestlers',09,'Pheonix',10001,504,204);
insert into address values(806,'new walt',70,'Santa Rosa',85142,505,205);

select *from address;

/*QUESTION 2*/

select 
	product.productName,
	product.price,
	Order_Table.orderID,
	poline.quantity,
	poline.totalCost 
from 
	product,
	Order_Table,
	poline 
where product.productID=poline.productID AND Order_Table.orderID=poline.orderID;


/*QUESION 3*/
select *from Customer CROSS JOIN Contact_Details;

/*QUESTION 4*/

update product set price=2.50 where productID=610;

/*QUESTION 5*/
select 
    Customer.Cust_FIRSTNAME,
    Customer.Cust_LASTNAME,
    Contact_Details.mobileNumber,
    Contact_Details.emailID
from
    Customer ,
    Contact_Details 
where
    Customer.customerID=Contact_Details.customerID;
    
/* QUESTION 6*/    
    
select 
    product.productName,
    product.price,
    poline.lineID,
    poline.quantity,
    poline.totalCost,
    poline.orderID,
    poline.productID
from 
    product product RIGHT OUTER JOIN POLine poline ON
    product.productID=poline.productID
ORDER BY
    productName DESC;
	
/* QUESTION 7*/
    
select productID from product
intersect 
select productID from poline;

/*QUESTION 8*/
select *from Contact_Details where customerID=200
union 
select *from Contact_Details where customerID=202;

/*QUESTION 9*/

/* CROSS JOIN

Cross join is nothing but cartesian product.

Cross joining refers to multiplying the number of rows in one table by the number of rows in another table.

Syntax :

Select * from First_table
cross join Second_table;

FULL OUTER JOIN:

FULL OUTER JOIN returns just matched or unmatched rows from the tables on both sides of the join clause and combines the results of both left and right outer joins.

Syntax:

SELECT *FROM First_table
FULL OUTER JOIN Second_table
ON First_table.Column= Second_table.Column;*/
	

/* QUESTION 10*/

/* Q 10.1
The following query is a correlated subquery because inner query is dependent on the outer query. Outer query is executed first and Inner query is executed for each row in outer query.

*/

/* 	Q 10.2

When there are 10 rows in the product table, the sub query will run 10 times.
*/

