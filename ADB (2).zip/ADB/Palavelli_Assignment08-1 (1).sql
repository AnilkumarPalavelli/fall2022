set serveroutput on;
DROP TABLE MyFoodDestination;
create table MyFoodDestination(
   Place_ID NUMBER(2) NOT NULL,
   Place_Name CHAR(40)NOT NULL,
   Special_Dish CHAR(40)NOT NULL,
   Dish_Price  FLOAT NOT NULL,
   PRIMARY KEY (Place_ID)
);

INSERT INTO  MyFoodDestination ( Place_ID,Place_Name,Special_Dish,Dish_Price) 
VALUES ('23','PistaHouse','Biryani','150');
INSERT INTO  MyFoodDestination ( Place_ID,Place_Name,Special_Dish,Dish_Price) 
VALUES ('57','CakesNBakes','Vadapav','35');
INSERT INTO  MyFoodDestination ( Place_ID,Place_Name,Special_Dish,Dish_Price) 
VALUES ('87','PullareddySweets','KazuBarfi','180');
INSERT INTO  MyFoodDestination ( Place_ID,Place_Name,Special_Dish,Dish_Price) 
VALUES ('98','SeshaSaiBakery','RoseMilk','100');


select *from myfooddestination;
/*Question 1 */
ACCEPT place_name CHAR PROMPT 'Select one place from  from PistaHouse,CakesNBakes,PullareddySweets,SeshaSaiBakery: '

create or replace procedure  mydish(place char)
is recipe char(40);

BEGIN
dbms_output.put_line('the place you have selected is : '||place);
SELECT Special_Dish INTO recipe FROM MyFoodDestination WHERE Place_Name=place;
dbms_output.put_line('The special dish in '|| place || 'is' || recipe);

EXCEPTION
WHEN OTHERS THEN
dbms_output.put_line('I dont have any special dish in'||place);
END;

execute mydish('&place_name');


/* Question 2 */
create or replace function FindAverage
return number
is
    avrg number;
begin
    select avg(Dish_Price) into avrg from  MyFoodDestination;
    return avrg;
end;



/* Question 3 */
create or replace procedure PrintAverage   
is
begin
    dbms_output.put_line('The average value is '||FindAverage);
end;


execute PrintAverage;


/* Question 4 */
create or replace function FindMax
return number
is
    maxi number;
begin
    select MAX (Dish_Price) into maxi from  MyFoodDestination;
    return maxi;
end;


/* Question 5 */
create or replace procedure PrintMax   
is food VARCHAR2(40);
begin
    SELECT Special_Dish INTO food FROM MYFOODDESTINATION WHERE DISH_PRICE=FindMax;
    dbms_output.put_line('The name of the dish with maximum price is '||food||'and the price is'||FindMax);
end;


execute printMax;